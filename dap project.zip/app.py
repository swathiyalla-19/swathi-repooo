"""
Student Tracker — Flask Backend
================================
REST API  +  SQLite persistence  +  serves the frontend HTML

Run:
    python app.py

Then open:  http://localhost:5000
"""

import sqlite3
from contextlib import contextmanager
from flask import Flask, request, jsonify, send_from_directory, Response
import os

# ─── App Setup ────────────────────────────────────────────────────────────────

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, "students.db")

app = Flask(__name__, static_folder=BASE_DIR)
app.config["JSON_SORT_KEYS"] = False

# ─── CORS (manual — no flask-cors needed) ─────────────────────────────────────

def add_cors(response):
    response.headers["Access-Control-Allow-Origin"]  = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return response

app.after_request(add_cors)

@app.route("/api/<path:path>", methods=["OPTIONS"])
def handle_options(path):
    return Response(status=200)

# ─── Database ─────────────────────────────────────────────────────────────────

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Create table and seed with sample data if empty."""
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                name    TEXT    NOT NULL,
                roll    TEXT    NOT NULL UNIQUE,
                att     INTEGER NOT NULL CHECK(att BETWEEN 0 AND 100),
                math    INTEGER NOT NULL DEFAULT 0 CHECK(math  BETWEEN 0 AND 100),
                phy     INTEGER NOT NULL DEFAULT 0 CHECK(phy   BETWEEN 0 AND 100),
                chem    INTEGER NOT NULL DEFAULT 0 CHECK(chem  BETWEEN 0 AND 100),
                eng     INTEGER NOT NULL DEFAULT 0 CHECK(eng   BETWEEN 0 AND 100),
                hist    INTEGER NOT NULL DEFAULT 0 CHECK(hist  BETWEEN 0 AND 100),
                cs      INTEGER NOT NULL DEFAULT 0 CHECK(cs    BETWEEN 0 AND 100)
            )
        """)

        # Seed only when table is empty
        count = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        if count == 0:
            seed = [
                ("Swathi",  "01", 92, 88, 79, 82, 91, 76, 90),
                ("Priya",   "02", 85, 74, 68, 71, 80, 65, 78),
                ("Lalitha", "03", 78, 62, 55, 60, 72, 58, 65),
                ("Saranya", "04", 95, 95, 91, 88, 96, 89, 97),
                ("Mounika", "05", 70, 58, 50, 45, 65, 52, 60),
                ("Devi",    "06", 88, 80, 75, 77, 85, 71, 83),
                ("Reshma",  "07", 62, 45, 40, 38, 55, 42, 50),
                ("Jhansi",  "08", 91, 86, 82, 80, 89, 78, 92),
                ("Divya",   "09", 74, 65, 60, 58, 70, 62, 68),
                ("Aparna",  "10", 83, 72, 68, 65, 78, 66, 75),
            ]
            conn.executemany(
                "INSERT INTO students(name,roll,att,math,phy,chem,eng,hist,cs) VALUES(?,?,?,?,?,?,?,?,?)",
                seed,
            )


def row_to_dict(row):
    return dict(row)

# ─── Validation helper ────────────────────────────────────────────────────────

def parse_student(data: dict, partial=False):
    """
    Validate and coerce student fields.
    Returns (obj_dict, error_str).  error_str is None on success.
    """
    errors = []

    name = str(data.get("name", "")).strip()
    roll = str(data.get("roll", "")).strip()

    if not partial or "name" in data:
        if not name:
            errors.append("'name' is required")

    if not partial or "roll" in data:
        if not roll:
            errors.append("'roll' is required")

    marks = {}
    for field in ("att", "math", "phy", "chem", "eng", "hist", "cs"):
        val = data.get(field)
        if val is None:
            if not partial:
                errors.append(f"'{field}' is required")
            continue
        try:
            val = int(val)
        except (TypeError, ValueError):
            errors.append(f"'{field}' must be an integer")
            continue
        if not (0 <= val <= 100):
            errors.append(f"'{field}' must be between 0 and 100")
            continue
        marks[field] = val

    if errors:
        return None, "; ".join(errors)

    obj = {"name": name, "roll": roll, **marks}
    return obj, None

# ─── API Routes ───────────────────────────────────────────────────────────────

@app.route("/api/students", methods=["GET"])
def list_students():
    """
    GET /api/students
    Query params:
        q       – search substring matched against name or roll (case-insensitive)
        sort    – column name to sort by (default: id)
        order   – asc | desc (default: asc)
        page    – page number (1-based, default: 1)
        limit   – records per page (default: 50, max: 200)
    """
    q     = request.args.get("q", "").strip().lower()
    sort  = request.args.get("sort", "id")
    order = request.args.get("order", "asc").lower()
    page  = max(1, int(request.args.get("page",  1)))
    limit = min(200, max(1, int(request.args.get("limit", 50))))

    allowed_cols = {"id","name","roll","att","math","phy","chem","eng","hist","cs"}
    if sort not in allowed_cols:
        sort = "id"
    if order not in ("asc", "desc"):
        order = "asc"

    offset = (page - 1) * limit

    with get_db() as conn:
        if q:
            base  = "WHERE LOWER(name) LIKE ? OR LOWER(roll) LIKE ?"
            args  = (f"%{q}%", f"%{q}%")
        else:
            base, args = "", ()

        total = conn.execute(f"SELECT COUNT(*) FROM students {base}", args).fetchone()[0]
        rows  = conn.execute(
            f"SELECT * FROM students {base} ORDER BY {sort} {order} LIMIT ? OFFSET ?",
            (*args, limit, offset),
        ).fetchall()

    students = [row_to_dict(r) for r in rows]

    # Summary counts (always across full dataset, not filtered)
    with get_db() as conn:
        counts = conn.execute("""
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN att >= 80 THEN 1 ELSE 0 END) AS good,
                SUM(CASE WHEN att >= 75 AND att < 80 THEN 1 ELSE 0 END) AS watch,
                SUM(CASE WHEN att < 75 THEN 1 ELSE 0 END) AS critical
            FROM students
        """).fetchone()

    return jsonify({
        "students": students,
        "summary": {
            "total":    counts["total"],
            "good":     counts["good"],
            "watch":    counts["watch"],
            "critical": counts["critical"],
        },
        "pagination": {
            "page":  page,
            "limit": limit,
            "total": total,
            "pages": (total + limit - 1) // limit,
        },
    })


@app.route("/api/students/<int:sid>", methods=["GET"])
def get_student(sid):
    """GET /api/students/:id — fetch one student."""
    with get_db() as conn:
        row = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
    if not row:
        return jsonify({"error": "Student not found"}), 404
    return jsonify(row_to_dict(row))


@app.route("/api/students", methods=["POST"])
def create_student():
    """POST /api/students — add a new student."""
    data = request.get_json(silent=True) or {}
    obj, err = parse_student(data)
    if err:
        return jsonify({"error": err}), 400

    try:
        with get_db() as conn:
            cur = conn.execute(
                "INSERT INTO students(name,roll,att,math,phy,chem,eng,hist,cs) VALUES(?,?,?,?,?,?,?,?,?)",
                (obj["name"], obj["roll"], obj["att"],
                 obj["math"], obj["phy"],  obj["chem"],
                 obj["eng"],  obj["hist"], obj["cs"]),
            )
            new_id = cur.lastrowid
            row = conn.execute("SELECT * FROM students WHERE id=?", (new_id,)).fetchone()
    except sqlite3.IntegrityError as exc:
        return jsonify({"error": f"Roll number already exists: {obj['roll']}"}), 409

    return jsonify(row_to_dict(row)), 201


@app.route("/api/students/<int:sid>", methods=["PUT"])
def update_student(sid):
    """PUT /api/students/:id — full update of a student."""
    data = request.get_json(silent=True) or {}
    obj, err = parse_student(data)
    if err:
        return jsonify({"error": err}), 400

    with get_db() as conn:
        existing = conn.execute("SELECT id FROM students WHERE id=?", (sid,)).fetchone()
        if not existing:
            return jsonify({"error": "Student not found"}), 404
        try:
            conn.execute(
                "UPDATE students SET name=?,roll=?,att=?,math=?,phy=?,chem=?,eng=?,hist=?,cs=? WHERE id=?",
                (obj["name"], obj["roll"], obj["att"],
                 obj["math"], obj["phy"],  obj["chem"],
                 obj["eng"],  obj["hist"], obj["cs"], sid),
            )
        except sqlite3.IntegrityError:
            return jsonify({"error": f"Roll number already exists: {obj['roll']}"}), 409
        row = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()

    return jsonify(row_to_dict(row))


@app.route("/api/students/<int:sid>", methods=["DELETE"])
def delete_student(sid):
    """DELETE /api/students/:id — remove a student."""
    with get_db() as conn:
        row = conn.execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone()
        if not row:
            return jsonify({"error": "Student not found"}), 404
        conn.execute("DELETE FROM students WHERE id=?", (sid,))
    return jsonify({"message": "Deleted", "student": row_to_dict(row)})


@app.route("/api/students/export", methods=["GET"])
def export_csv():
    """GET /api/students/export — download all students as CSV."""
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM students ORDER BY id").fetchall()

    lines = ["id,name,roll,att,math,phy,chem,eng,hist,cs"]
    for r in rows:
        lines.append(f"{r['id']},{r['name']},{r['roll']},{r['att']},"
                     f"{r['math']},{r['phy']},{r['chem']},{r['eng']},{r['hist']},{r['cs']}")

    csv_data = "\n".join(lines)
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=students.csv"},
    )


# ─── Serve Frontend ───────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve index.html from the same directory as app.py."""
    html_path = os.path.join(BASE_DIR, "index.html")
    if not os.path.exists(html_path):
        return (
            "<h2>index.html not found</h2>"
            "<p>Place <b>index.html</b> in the same folder as <b>app.py</b> and reload.</p>",
            404,
        )
    return send_from_directory(BASE_DIR, "index.html")

# ─── Error Handlers ───────────────────────────────────────────────────────────

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error"}), 500

# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    print("\n🎓  Student Tracker API  🚀")
    print("─" * 36)
    print("  Frontend :  http://localhost:5000")
    print("  API base :  http://localhost:5000/api")
    print()
    print("  Endpoints:")
    print("    GET    /api/students          – list / search")
    print("    POST   /api/students          – create")
    print("    GET    /api/students/:id      – fetch one")
    print("    PUT    /api/students/:id      – update")
    print("    DELETE /api/students/:id      – delete")
    print("    GET    /api/students/export   – CSV download")
    print("─" * 36 + "\n")
    app.run(debug=True, port=5000)
